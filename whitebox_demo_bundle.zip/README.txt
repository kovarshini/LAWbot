
Whitebox Legal Q&A — Demo bundle

Files generated in this folder:
- app.py                 : Flask demo (simple search API + static UI)
- templates/flask_index.html : Flask UI template
- streamlit_app.py       : Streamlit demo app
- qa.json                : Question-answer pairs (sample)
- assets/logo.png        : Generated logo PNG
- requirements.txt       : Python packages to install

How to run (Flask):
1. python -m venv venv && source venv/bin/activate   (Windows: venv\Scripts\activate)
2. pip install -r requirements.txt
3. cd whitebox_demo_bundle
4. python app.py
5. Open http://127.0.0.1:8501 in your browser

How to run (Streamlit):
1. python -m venv venv && source venv/bin/activate
2. pip install -r requirements.txt
3. cd whitebox_demo_bundle
4. streamlit run streamlit_app.py

Notes on integrating your RAG/model:
- Replace the naive matching logic in app.py and streamlit_app.py with calls to your retrieval pipeline.
- Implement an endpoint /api/retrieve that accepts a query, generates embeddings,
  searches your vector DB (FAISS/Chromadb), and returns top passages to be used to build the answer.
- Secure API keys and never expose private data to the client side.

Edit access:
- Files are saved under: {out_dir}
- Download the bundle and edit locally, or open them in VSCode/Jupyter in the running environment.
