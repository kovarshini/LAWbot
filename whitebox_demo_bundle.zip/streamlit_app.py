
import streamlit as st, json, os
APP_DIR = os.path.dirname(__file__)
with open(os.path.join(APP_DIR,"qa.json"),"r",encoding="utf-8") as f:
    QA = json.load(f)

st.set_page_config(page_title="Whitebox Legal Q&A (Streamlit Demo)", layout="wide", initial_sidebar_state="expanded")
st.sidebar.image(os.path.join("assets","logo.png"), width=120)
st.sidebar.title("Whitebox Legal Q&A")
query = st.sidebar.text_input("Ask a question or search", "")

st.title("Whitebox Legal Q&A — Streamlit Demo")
st.write("Explainable RAG demo UI (templated answers). Not legal advice.")

col1, col2 = st.columns([1,2])
with col1:
    st.subheader("Questions")
    for i,item in enumerate(QA[:200]):
        if st.button(item['q'][:80], key=f"q{i}"):
            st.session_state['selected'] = i

with col2:
    sel = st.session_state.get('selected', None)
    if sel is not None:
        item = QA[sel]
        st.subheader(item['q'])
        st.info(item['a'])
    else:
        st.info("Select a question from the left or type a query in the sidebar.")

# Simple matching when query provided
if query:
    words = [w for w in query.lower().split() if w]
    scores = []
    for idx,item in enumerate(QA):
        score = sum(1 for w in words if w in item['q'].lower())
        scores.append((score, idx))
    scores.sort(reverse=True)
    best = [idx for s,idx in scores if s>0][:5]
    if best:
        st.subheader("Search results")
        for idx in best:
            st.write("**Q:**", QA[idx]['q'])
            st.write("**A:**", QA[idx]['a'])
    else:
        st.warning("No close match found. Integrate your RAG retrieval for robust results.")
