
from flask import Flask, render_template, request, jsonify, send_from_directory
import json, os

APP_DIR = os.path.dirname(__file__)
with open(os.path.join(APP_DIR, "qa.json"), "r", encoding="utf-8") as f:
    QA = json.load(f)

app = Flask(__name__, static_folder="assets", template_folder="templates")

@app.route("/")
def index():
    return render_template("flask_index.html")

@app.route("/api/search", methods=["POST"])
def api_search():
    data = request.json or {}
    q = data.get("q","").lower()
    if not q:
        return jsonify({"error":"empty query","results":QA[:10]})
    scored = []
    for item in QA:
        score = sum(1 for w in q.split() if w and w in item['q'].lower())
        scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    results = [it for s,it in scored if s>0]
    if not results:
        return jsonify({"results":QA[:5], "note":"No strong match found; replace with RAG retrieval for better results."})
    return jsonify({"results":results[:10]})

@app.route('/assets/<path:filename>')
def assets(filename):
    return send_from_directory(os.path.join(APP_DIR,'assets'), filename)

if __name__ == "__main__":
    app.run(debug=True, port=8501)
